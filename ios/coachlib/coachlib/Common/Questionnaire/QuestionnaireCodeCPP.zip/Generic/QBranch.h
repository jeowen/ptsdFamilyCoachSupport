/*
 *  QBranch.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QBRANCH_H
#define QBRANCH_H

#include "QAnd.h"

class QBranch : public QAnd {
	
	char *destination;

public:

	QBranch();

	virtual const char *getDestination();
	virtual void setDestination(const char *_destination);
	virtual void *evaluate(QAbstractPlayer *ctx);
};

#endif
