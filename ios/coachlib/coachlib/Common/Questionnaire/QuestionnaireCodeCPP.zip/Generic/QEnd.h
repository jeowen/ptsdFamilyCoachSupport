/*
 *  QEnd.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QEND_H
#define QEND_H

#include "QScreen.h"

class QEnd : public QScreen {
public:

	virtual void addButtons(QAbstractPlayer *ctx);
	
};

#endif
