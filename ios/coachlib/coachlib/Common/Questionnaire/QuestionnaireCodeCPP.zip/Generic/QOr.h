/*
 *  QOr.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QOR_H
#define QOR_H

#include "QCompositeCondition.h"

class QOr : public QCompositeCondition {
public:
	virtual void *evaluate(QAbstractPlayer *q);
};

#endif
