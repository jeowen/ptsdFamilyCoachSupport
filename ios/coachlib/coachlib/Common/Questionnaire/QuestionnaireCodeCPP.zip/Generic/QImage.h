/*
 *  QImage.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QIMAGE_H
#define QIMAGE_H

#include "QNode.h"

class QImage : public QNode {
	
	char *url;
	
public:
	QImage();
	virtual ~QImage();
	
	virtual const char *getURL();
	virtual void setURL(const char *_url);
	virtual void *evaluate(QAbstractPlayer *ctx);
	
};

#endif
