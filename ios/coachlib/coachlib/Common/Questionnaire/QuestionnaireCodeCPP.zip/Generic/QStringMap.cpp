/*
 *  QStringMap.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/18/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QStringMap.h"

const char *QStringMap::get(const char *name) {
	return (const char *)_get(name);
}

void QStringMap::put(const char *name, const char *value) {
	_put(strdup(name),(void*)strdup(value), MAP_FLAG_FREE_NAME | MAP_FLAG_FREE_VALUE);
}

void QStringMap::deleteValue(void *value) {
	free(value);
}

