/*
 *  QInfo.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QInfo.h"
#include "QAbstractPlayer.h"

void *QInfo::evaluate(QAbstractPlayer *ctx) {
	ctx->addText(getText(ctx));
	return NULL;
}
