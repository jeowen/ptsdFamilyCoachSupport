/*
 *  QEnd.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QEnd.h"
#include "QQuestionnaire.h"

void QEnd::addButtons(QAbstractPlayer *ctx) {
	ctx->addButton(BUTTON_DONE,ctx->getQuestionnaire()->getSettings()->getGlobal(ctx, VAR_DONE_BUTTON));
}
