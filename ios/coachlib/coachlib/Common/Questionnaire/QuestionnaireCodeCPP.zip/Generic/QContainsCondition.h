/*
 *  QContainsCondition.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/18/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QCONTAINSCONDITION_H
#define QCONTAINSCONDITION_H

#include "QDefs.h"
#include "QNode.h"

class QContainsCondition : public QNode {
	
	char *variableName;
	char **values;

public:
	
	QContainsCondition(const char * variable, const char *values);
	
	virtual void* evaluate(QAbstractPlayer *q);
};

#endif
