/*
 *  QChoice.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QChoice.h"

QChoice::QChoice() {
	value = NULL;
}

int QChoice::getType() {
	return NODETYPE_CHOICE;
}

void QChoice::setValue(const char *_value) {
	if (value) free(value);
	value = _value ? strdup(_value) : NULL;
}

const char *QChoice::getValue() {
	return value;
}
