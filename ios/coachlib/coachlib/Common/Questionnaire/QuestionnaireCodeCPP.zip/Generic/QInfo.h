/*
 *  QInfo.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QINFO_H
#define QINFO_H

#include "QTextContainer.h"

class QInfo : public QTextContainer {
public:
	virtual void *evaluate(QAbstractPlayer *ctx);
};

#endif
