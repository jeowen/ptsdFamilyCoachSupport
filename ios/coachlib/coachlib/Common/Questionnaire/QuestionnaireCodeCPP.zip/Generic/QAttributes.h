/*
 *  QMap.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QATTRIBUTES_H
#define QATTRIBUTES_H

#include "QDefs.h"

class QAttributes {
public:
	virtual const char *get(const char *name) = 0;
};

#endif
