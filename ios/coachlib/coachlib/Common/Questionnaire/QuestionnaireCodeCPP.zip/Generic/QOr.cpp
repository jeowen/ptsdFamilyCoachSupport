/*
 *  QOr.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QOr.h"
#include "QUtil.h"

void *QOr::evaluate(QAbstractPlayer *q) {
	if (!subnodes) return NULL;
	for (int i=0;i<subnodeCount;i++) {
		if (QUtil::isTrue(subnodes[i]->evaluate(q))) return (void*)INT_MAX;
	}
	return NULL;
}
