/*
 *  QAnd.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QAnd.h"
#include "QUtil.h"

void *QAnd::evaluate(QAbstractPlayer *q) {
	if (!subnodes) return (void*)INT_MAX;
	for (int i=0;i<subnodeCount;i++) {
		if (!QUtil::isTrue(subnodes[i]->evaluate(q))) return NULL;
	}
	return (void*)INT_MAX;
}
