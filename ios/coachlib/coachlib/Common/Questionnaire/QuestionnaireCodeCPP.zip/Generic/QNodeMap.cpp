/*
 *  QNodeMap.cpp
 *  iStressLess
 *
 *  Created by George Hoffman on 8/18/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QNodeMap.h"
#include "QNode.h"

QNode *QNodeMap::get(const char *name) {
	return (QNode *)_get(name);
}

void QNodeMap::put(const char *name, QNode *n) {
	_put(strdup(name),(void*)n, MAP_FLAG_FREE_NAME );
}

void QNodeMap::deleteValue(void *value) {
//	QNode *n = (QNode*)value;
//	delete n;
}

