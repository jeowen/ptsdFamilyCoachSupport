/*
 *  QIntroScreen.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "QScreen.h"

class QAbstractPlayer;

class QIntroScreen : public QScreen {
	
	virtual int  screenType(QAbstractPlayer *ctx);
	virtual void addButtons(QAbstractPlayer *ctx);
	
};
