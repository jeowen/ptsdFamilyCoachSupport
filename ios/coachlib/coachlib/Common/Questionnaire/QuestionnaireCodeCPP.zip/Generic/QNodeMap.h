/*
 *  QNodeMap.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/18/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QNODEMAP_H
#define QNODEMAP_H

#include "QDefs.h"
#include "QBaseMap.h"

class QNode;

class QNodeMap : public QBaseMap {
public:
	QNode *get(const char *name);
	void put(const char *name, QNode *n);
	virtual void deleteValue(void *value);
};

#endif
