/*
 *  QCompositeCondition.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QCOMPOSITECONDITION_H
#define QCOMPOSITECONDITION_H

#include "QNode.h"

class QCompositeCondition : public QNode {
public:
	virtual void startElement(const char *localName, QAttributes *attributes, QHandler *handler);
};

#endif
