/*
 *  QAnd.h
 *  iStressLess
 *
 *  Created by George Hoffman on 8/17/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef QAND_H
#define QAND_H

#include "QCompositeCondition.h"

class QAnd : public QCompositeCondition {
public:
	virtual void *evaluate(QAbstractPlayer *q);
	
};

#endif
